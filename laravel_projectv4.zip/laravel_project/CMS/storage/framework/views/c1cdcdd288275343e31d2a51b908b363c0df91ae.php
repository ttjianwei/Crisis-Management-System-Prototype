<?php $__env->startSection('content'); ?>
	<p><b><center>Privilege level : Email Liaison</center></b></p>
	
	
	
	
	<body>
	

<div style="margin-left:100px">
<label for="id">

            <strong>
			Enter facebook post : </strong>
          </label>
		  
		  
 <?php echo Form::open(array('url'=>'facebookPost','method'=>'post')); ?>

   <?php echo Form::text('facebookPost',null,array('class'=>'input' , 'id'=>'facebookPost','style'=>'width:800px')); ?>

	 		 <?php echo Form::submit('Publish'); ?>

	 <?php echo Form::close(); ?>

	 
	 
	 <p>
	 </p>
	 
	    <strong>
			Enter Twitter post : </strong>
          </label>
	  <?php echo Form::open(array('url'=>'twitterPost','method'=>'post','onsubmit'=>'return confirm("Sent!");')); ?>

      <?php echo Form::text('tweet',null,array('class'=>'input' , 'id'=>'twitterPost','style'=>'width:800px')); ?>

	 		 <?php echo Form::submit('Publish'); ?>

	 <?php echo Form::close(); ?>

	 
	 	 
	 <p>
	 </p>
	 
	    <strong>
			Enter SMS notification : </strong>
          </label>
	  <?php echo Form::open(array('url'=>'sendSMS','method'=>'post','onsubmit'=>'return confirm("Sent!");')); ?>

      <?php echo Form::text('id',null,array('class'=>'input' , 'id'=>'sms','style'=>'width:800px')); ?>

	 		 <?php echo Form::submit('Send'); ?>

	 <?php echo Form::close(); ?>

	 </div>
	 
	 
	 
	 
	 
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publicSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>