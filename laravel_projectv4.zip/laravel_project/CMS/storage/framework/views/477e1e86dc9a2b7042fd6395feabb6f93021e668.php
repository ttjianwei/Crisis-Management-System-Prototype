<?php $__env->startSection('content'); ?>
	
	<p><b><center>Privilege level : Key Appointment Holder</center></b></p>
	<table>
  <thead>
    <tr>
	  <th>Email ID</th>
      <th>Email Subject</th>
      <th>Sender</th>
      <th>Time sent</th>
    </tr>
  </table>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pmoSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>