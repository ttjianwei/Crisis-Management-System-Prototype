<!DOCTYPE html>

<html >
  <head>
    <meta charset="UTF-8">
    <title>Welcome to C.R.U.X Login</title>
	<link rel="stylesheet" type ="text/css" href="assets/css/login.css"/>
	<style>
</style>
    
 
    
  </head>

  <body>


    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
	
  <?php echo Form::open(array('url'=>'login','method'=>'post')); ?>

  <p>
    <?php echo $errors->first('Error'); ?>

	</p>
	<p>
	<font size="45" color="Navy"> C.R.U.X CMS</font>
	
	
	</p>
	<font size="45"> </font>
	  <?php echo Form::text('name',null,array('placeholder'=>'Enter Username','class'=>'input' , 'id'=>'name' )); ?>

		  <?php echo Form::password('password',array('placeholder'=>'Enter Password')); ?>

			  <?php echo Form::submit('Log In'); ?>

		<?php echo Form::close(); ?>

    

  </body>
</html>
	
    