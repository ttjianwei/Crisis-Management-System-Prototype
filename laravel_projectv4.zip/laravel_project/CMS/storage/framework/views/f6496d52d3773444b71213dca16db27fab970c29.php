
<nav id="sidebar-nav">
	<ul class="nav nav-pills nav-stacked">
	<li><a href="#">Fly to the Moon</a></li>
	<li><a href="#">Dig to china</a></li>
	<li><a href="#">Swim across the sea</a></li>
	</ul>
</nav>
	