<?php $__env->startSection('content'); ?>

<p><b><center>Privilege level : Operator</center></b></p>
<center>
<iframe src="https://www.chatcrypt.com/iframe.php" width="468" height="60" frameborder="0"></iframe>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.operatorSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>