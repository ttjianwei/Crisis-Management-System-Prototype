<?php $__env->startSection('content'); ?>
	<p><b><center>Privilege level : SCDF Commander</center></b></p>
	
<script>

  function ConfirmDelete()
  {
  var x = confirm("Confirm delete asset?");
  if (x)
    return true;
  else
    return false;
  }
  
</script>	
	<table>
  <thead>
     <tr>
	  <th>Assets ID</th>
      <th>Assets Name</th>
      <th>Assets Description</th>
	  <th>Assets Type</th>
	  <th>Assets Deployment Location</th>
	  <th>Assets Status</th>
	  <th>Assets Department</th>
	  <th>Remarks</th>
	  <th>Delete</th>
    </tr>
  </thead>

  <tbody>
     <tr>
	  <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	 <tr>
	 <td><?php echo $asset->assetID; ?></td>
	 <td><?php echo $asset->assetName; ?></td>
	 <td><?php echo $asset->assetDescription; ?></td>
	 <td><?php echo $asset->assetType; ?></td>
	 <td><?php echo $asset->assetLocation; ?></td> 
	 <td><?php echo $asset->assetStatus; ?></td>
	 <td><?php echo $asset->assetDepartment; ?></td>
	 <td><?php echo $asset->assetRemarks; ?></td>
	 
	 <?php if($asset->assetDepartment =='SCDF' || $asset->assetDepartment =='scdf' ): ?>
	 <td> 
	 <?php echo Form::open(array('url'=>'deleteAssets','method'=>'post','onsubmit' => 'return ConfirmDelete()')); ?>

	 		 <?php echo Form::submit('Delete'); ?>

			 <?php echo Form::hidden('assetID', $asset->assetID ); ?>

	 <?php echo Form::close(); ?>

	 
	 </td>
	 <?php endif; ?>
	 
	 </tr>
	   <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  
	
  </tbody>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.scdfSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>