<?php $__env->startSection('content'); ?>
<script>

  function ConfirmCreate()
  {
  var x = confirm("Confirm create asset?");
  if (x)
    return true;
  else
    return false;
  }
  
</script>
	<p><b><center>Privilege level : SAF Commander</center></b></p>
	  <body>
    <h1>Add Asset</h1>

	<?php echo Form::open(array('url'=>'addAssets','method'=>'post','onsubmit' => 'return ConfirmCreate()')); ?>

      <fieldset>
        <legend>New Asset</legend>
		  <div>
          <label for="assetID">
            <strong>Asset ID : </strong>
          </label>
		   <?php echo Form::text('assetID',null,array('class'=>'input' , 'id'=>'name' )); ?>

        </div>
        <div>
          <label for="assetName">
            <strong>Asset Name : </strong>
          </label>
          <input id="assetName" name="assetName" type="text">
        </div>
		
		   <div>
          <label for="assetType">
            <strong>Asset Type :</strong>
          </label>
          <input id="assetType" name="assetType" type="text">
        </div>
		
			   <div>
          <label for="assetLocation">
            <strong>Asset Location :</strong>
          </label>
          <input id="assetLocation" name="assetLocation" type="text">
        </div>
		
        <div>
          <label for="assetDescription">
            <strong>Asset Description :</strong>
          </label>
          <textarea id="assetDescription" name="assetDescription"></textarea>
        </div>
		   <div>
          <label for="assetStatus">
            <strong>Asset Status :</strong>
          </label>
               <input id="assetStatus" name="assetStatus" type="text">
        </div>
		
		   <div>
          <label for="assetDepartment">
            <strong>Asset Department :</strong>
          </label>
          <select name="assetDepartment" id="assetDepartment">
		 <option value="SCDF">SCDF</option>
		 <option value="NEA">NEA</option>
		 <option value="SAF">SAF</option>
		 <option value="SPF">SPF</option>
		  </select>
		  
        </div>
		
      </fieldset>
      <fieldset>  
        <legend>Asset metadata</legend>
        <div class="inline">
          <label for="assetRemarks">
            <strong>Asset Remarks :</strong>
          </label>
          <input id="assetRemarks" name="assetRemarks" type="text">
        </div>
      </fieldset
	 
      <p>
         <?php echo Form::submit('Add'); ?>

      </p>
   	 <?php echo Form::close(); ?>


  </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.safSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>