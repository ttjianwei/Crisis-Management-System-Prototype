<?php $__env->startSection('content'); ?>
	<p><b><center>Privilege level : Operator</center></b></p>
	<table>
  <thead>
    <tr>
	  <th>Incident case ID</th>
      <th>Incident Name</th>
	  <th>Time of Incident</th>
	  <th>Edit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
	  <?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	 <tr>
	 <td><?php echo e($incident->caseID); ?></td>
	 <td><?php echo e($incident->incidentName); ?></td>
	 <td><?php echo $incident->datetimeOfIncident; ?></td>
	 <td> 
	 <?php echo Form::open(array('url'=>'operatorEditIncident','method'=>'post')); ?>

	 <?php echo Form::hidden('caseID', $incident->caseID ); ?>

	 <?php echo Form::submit('Update'); ?>

	 <?php echo Form::close(); ?>

	 </td>
	 
	 </tr>
	   <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
   

  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.operatorSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>