<!doctype html>
<html>

<head>

	<?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
</head>
<body>
	<?php echo $__env->make('includes.spfHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div id="main" class="row">
	
	
		<div id="content" class="col-mid-8">
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</div>
	</body>
	</html>