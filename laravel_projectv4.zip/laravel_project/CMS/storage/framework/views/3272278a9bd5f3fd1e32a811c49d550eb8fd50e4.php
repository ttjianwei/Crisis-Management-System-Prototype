<?php $__env->startSection('content'); ?>
<b><center>Privilege level : Email Manager</center></b>
<body>
    <h1>Create Email</h1>
	
	
	  
	  
	  
<?php echo Form::open(array('url'=>'sendEmail','method'=>'post','onsubmit'=>'return confirm("Sent!");')); ?>

      <fieldset>
        <legend>New Email </legend>

        <div>
          <label for="">
            <strong>Subject : </strong>
          </label>
          <input id="subject" name="subject" type="text">
        </div>
		
		   <div>
          <label for="senderName">
            <strong>Operator Name :</strong>
          </label>
          <input id="senderName" name="senderName" type="text">
        </div>
		
        <div>
          <label for="message">
            <strong>Message :</strong>
          </label>
          <textarea id="message" name="message"></textarea>
        </div>
      </fieldset>
	<p>
	<center>
	 </p>
	      <?php echo Form::submit('Create'); ?>

     </p>
   	 <?php echo Form::close(); ?>

</center>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.emailSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>