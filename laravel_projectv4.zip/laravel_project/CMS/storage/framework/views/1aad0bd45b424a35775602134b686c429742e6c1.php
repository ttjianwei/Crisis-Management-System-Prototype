<?php $__env->startSection('content'); ?>
	<p><b><center>Privilege level : SAF Commander</center></b></p>
<!DOCTYPE html >
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>C.R.U.X CMS </title>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD3O2hxSSW3mBVl1hR-relUMeiijJ3-caM"
            type="text/javascript"></script>
    <script type="text/javascript">
    //<![CDATA[

    var customIcons = {
      Flood: {
        icon: 'http://labs.google.com/ridefinder/images/mm_20_blue.png'
      },
      Fire: {
        icon: 'http://labs.google.com/ridefinder/images/mm_20_orange.png'
      },
	   Asset: {
        icon: 'http://labs.google.com/ridefinder/images/mm_20_green.png'
      },
	  Crisis: {
        icon: 'http://labs.google.com/ridefinder/images/mm_20_red.png'
      }
	  
    };

    function load() {
      var map = new google.maps.Map(document.getElementById("map"), {
        center: new google.maps.LatLng(1.352083 , 103.8198),
        zoom: 11,
        mapTypeId: 'roadmap'
      });
      var infoWindow = new google.maps.InfoWindow;

      // Change this depending on the name of your PHP file
      downloadUrl("data.php", function(data) {
        var xml = data.responseXML;
        var markers = xml.documentElement.getElementsByTagName("marker");
        for (var i = 0; i < markers.length; i++) {
          var name = markers[i].getAttribute("name");
          var address = markers[i].getAttribute("address");
          var type = markers[i].getAttribute("type");
          var point = new google.maps.LatLng(
              parseFloat(markers[i].getAttribute("lat")),
              parseFloat(markers[i].getAttribute("lng")));
          var html = "<b>" + name + "</b> <br/>" + address;
          var icon = customIcons[type] || {};
          var marker = new google.maps.Marker({
            map: map,
            position: point,
            icon: icon.icon
          });
          bindInfoWindow(marker, map, infoWindow, html);
        }
      });
    }

    function bindInfoWindow(marker, map, infoWindow, html) {
      google.maps.event.addListener(marker, 'click', function() {
        infoWindow.setContent(html);
        infoWindow.open(map, marker);
      });
    }

    function downloadUrl(url, callback) {
      var request = window.ActiveXObject ?
          new ActiveXObject('Microsoft.XMLHTTP') :
          new XMLHttpRequest;

      request.onreadystatechange = function() {
        if (request.readyState == 4) {
          request.onreadystatechange = doNothing;
          callback(request, request.status);
        }
      };

      request.open('GET', url, true);
      request.send(null);
    }
	
	function initNorth() {
      var map = new google.maps.Map(document.getElementById("map"), {
        center: new google.maps.LatLng(1.436 , 103.7861),
        zoom: 8,
        mapTypeId: 'roadmap'
      });
	  
	
	  
      var infoWindow = new google.maps.InfoWindow;

      // Change this depending on the name of your PHP file
      downloadUrl("data.php", function(data) {
        var xml = data.responseXML;
        var markers = xml.documentElement.getElementsByTagName("marker");
        for (var i = 0; i < markers.length; i++) {
          var name = markers[i].getAttribute("name");
          var address = markers[i].getAttribute("address");
          var type = markers[i].getAttribute("type");
          var point = new google.maps.LatLng(
              parseFloat(markers[i].getAttribute("lat")),
              parseFloat(markers[i].getAttribute("lng")));
          var html = "<b>" + name + "</b> <br/>" + address;
          var icon = customIcons[type] || {};
          var marker = new google.maps.Marker({
            map: map,
            position: point,
            icon: icon.icon
          });
          bindInfoWindow(marker, map, infoWindow, html);
        }
      });
    }
	
	  
	function initSouth() {
      var map = new google.maps.Map(document.getElementById("map"), {
        center: new google.maps.LatLng(1.294166 , 103.786127),
        zoom: 8,
        mapTypeId: 'roadmap'
      });
	  
	  
      var infoWindow = new google.maps.InfoWindow;

      // Change this depending on the name of your PHP file
      downloadUrl("data.php", function(data) {
        var xml = data.responseXML;
        var markers = xml.documentElement.getElementsByTagName("marker");
        for (var i = 0; i < markers.length; i++) {
          var name = markers[i].getAttribute("name");
          var address = markers[i].getAttribute("address");
          var type = markers[i].getAttribute("type");
          var point = new google.maps.LatLng(
              parseFloat(markers[i].getAttribute("lat")),
              parseFloat(markers[i].getAttribute("lng")));
          var html = "<b>" + name + "</b> <br/>" + address;
          var icon = customIcons[type] || {};
          var marker = new google.maps.Marker({
            map: map,
            position: point,
            icon: icon.icon
          });
          bindInfoWindow(marker, map, infoWindow, html);
        }
      });
    }
	  
	  
	function initEast() {
      var map = new google.maps.Map(document.getElementById("map"), {
        center: new google.maps.LatLng(1.323604 , 103.927341),
        zoom: 8,
        mapTypeId: 'roadmap'
      });
	  
	  
      var infoWindow = new google.maps.InfoWindow;

      // Change this depending on the name of your PHP file
      downloadUrl("data.php", function(data) {
        var xml = data.responseXML;
        var markers = xml.documentElement.getElementsByTagName("marker");
        for (var i = 0; i < markers.length; i++) {
          var name = markers[i].getAttribute("name");
          var address = markers[i].getAttribute("address");
          var type = markers[i].getAttribute("type");
          var point = new google.maps.LatLng(
              parseFloat(markers[i].getAttribute("lat")),
              parseFloat(markers[i].getAttribute("lng")));
          var html = "<b>" + name + "</b> <br/>" + address;
          var icon = customIcons[type] || {};
          var marker = new google.maps.Marker({
            map: map,
            position: point,
            icon: icon.icon
          });
          bindInfoWindow(marker, map, infoWindow, html);
        }
      });
    }
	  
	  
	function initWest() {
      var map = new google.maps.Map(document.getElementById("map"), {
        center: new google.maps.LatLng(1.332857 , 103.743552),
        zoom: 8,
        mapTypeId: 'roadmap'
      });
	  
	  
      var infoWindow = new google.maps.InfoWindow;

      // Change this depending on the name of your PHP file
      downloadUrl("data.php", function(data) {
        var xml = data.responseXML;
        var markers = xml.documentElement.getElementsByTagName("marker");
        for (var i = 0; i < markers.length; i++) {
          var name = markers[i].getAttribute("name");
          var address = markers[i].getAttribute("address");
          var type = markers[i].getAttribute("type");
          var point = new google.maps.LatLng(
              parseFloat(markers[i].getAttribute("lat")),
              parseFloat(markers[i].getAttribute("lng")));
          var html = "<b>" + name + "</b> <br/>" + address;
          var icon = customIcons[type] || {};
          var marker = new google.maps.Marker({
            map: map,
            position: point,
            icon: icon.icon
          });
          bindInfoWindow(marker, map, infoWindow, html);
        }
      });
    }
	  
	
    function doNothing() {}

    //]]>

  </script>

  </head>

  <center>
  <body onload="load()">
  	
	<table>
	<tr>
	<td>
	 <h3><a id='north' href="#" onclick="initNorth();return false;">North</a></h3>
	 </td>
	 
	<td>
	  <h3><a id='south' href="#" onclick="initSouth();return false;">South</a></h3>
	  </td>

	<td>
	  <h3><a id='west' href="#" onclick="initWest();return false;">West</a></h3>
	  </td>

	<td>
	  <h3><a id='east' href="#" onclick="initEast();return false;">East</a></h3>
	  </td>


	<td>
	  <h3><a id='main' href="#" onclick="load();return false;">Main</a></h3>
	  </td>
	
  </tr>
	</table>
  <table>
  <tr>
  <td>
  <img src="legends.png" alt="Mountain View">
  </td>
  <td>
   <div id="map" style="width: 800px; height: 500px"></div>
 </td>
	</tr>
	</table>

  </body>
</center>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.safSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>