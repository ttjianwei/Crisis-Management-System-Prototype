<?php $__env->startSection('content'); ?>
	<p><b><center>Privilege level : SPF Commander</center></b></p>
		
<table>
  <thead>
    <tr>
	  <th>Incident case ID</th>
      <th>Incident Name</th>
      <th>Incident Category</th>
      <th>Incident Description</th>
	  <th>Incident Location</th>
	  <th>Alert Level</th>
	  <th>Remarks</th>
	  <th>Logged by</th>
	  <th>Time of Incident</th>
    </tr>
  </thead>
  <tbody>
    
	  <?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	 <tr>
	 <td><?php echo $incident->caseID; ?></td>
	 <td><?php echo $incident->incidentName; ?></td>
	 <td><?php echo $incident->incidentCategory; ?></td>
	 <td><?php echo $incident->description; ?></td>
	 <td><?php echo $incident->incidentLocation; ?></td>
	 <td><?php echo $incident->alertLevel; ?></td>
	 <td><?php echo $incident->remarks; ?></td>
	 <td><?php echo $incident->loggedBy; ?></td>
	 <td><?php echo $incident->datetimeOfIncident; ?></td>
	 </tr>
	   <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  
   

  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.spfSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>