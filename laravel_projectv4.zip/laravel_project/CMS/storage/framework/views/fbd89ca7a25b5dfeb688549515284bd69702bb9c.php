<?php $__env->startSection('content'); ?>
	<p><b><center>Privilege level : Key Appointment Holder</center></b></p>
	
<table>
  <thead>
     <tr>
      <th>Crisis ID</th>
      <th>Crisis Name</th>
	  <th>Crisis Location</th>
	  <th>Crisis Category</th>
	  <th>Description</th>
	  <th>Remarks</th>
	  <th>Crisis Level</th>
	  <th>Crisis Logged By</th>
	  <th>Crisis Datetime</th>
	 
    </tr>
  </thead>

  <tbody>
     <tr>
	  <?php $__currentLoopData = $allCrisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crisis): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	 <tr>
	 <td><?php echo e($crisis->caseID); ?></td>
	 <td><?php echo e($crisis->crisisName); ?></td>
	 <td><?php echo e($crisis->crisisLocation); ?></td>
	 <td><?php echo e($crisis->crisisCategory); ?></td>
	 <td><?php echo e($crisis->crisisDescription); ?></td>
	 <td><?php echo e($crisis->crisisRemarks); ?></td>
	 <td><?php echo e($crisis->crisisLevel); ?></td>
	 <td><?php echo e($crisis->crisisLoggedBy); ?></td>
	 <td><?php echo e($crisis->crisisDateTime); ?></td>
	 </tr>
	   <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  
	
  </tbody>
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pmoSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>