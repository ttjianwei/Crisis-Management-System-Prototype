<?php $__env->startSection('content'); ?>
<script>

  function ConfirmUpdate()
  {
  var x = confirm("Confirm update Incident Level?");
  if (x)
    return true;
  else
    return false;
  }
  
</script>

	<p><b><center>Privilege level : Operator</center></b></p>
<table>
  <thead>
    <tr>
	  <th>Incident case ID</th>
      <th>Incident Name</th>
      <th>Incident Category</th>
      <th>Incident Description</th>
	  <th>Incident Location</th>
	  <th>Alert Level</th>
	  <th>Remarks</th>
	  <th>Lodge by</th>
	  <th>Time of Incident</th>
	  <th>Increase Alert level</th>
    </tr>
  </thead>
  <tbody>
    <tr>
	  <?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	 <tr>
	 <td><?php echo $incident->caseID; ?></td>
	 <td><?php echo $incident->incidentName; ?></td>
	 <td><?php echo $incident->incidentCategory; ?></td>
	 <td><?php echo $incident->description; ?></td>
	 <td><?php echo $incident->incidentLocation; ?></td>
	 <td><?php echo $incident->alertLevel; ?></td>
	 <td><?php echo $incident->remarks; ?></td>
	 <td><?php echo $incident->loggedBy; ?></td>
	 <td><?php echo $incident->datetimeOfIncident; ?></td>
	 <td> 
	 <?php echo Form::open(array('url'=>'updateThreat','method'=>'post','onsubmit' => 'return ConfirmUpdate()')); ?>

	 <?php echo Form::select('threat',array('ALERT 1' => 'ALERT 1', 'ALERT 2' => 'ALERT 2','ALERT 3' => 'ALERT 3','ALERT 4' => 'ALERT 4'));; ?>

	 <?php echo Form::hidden('caseID', $incident->caseID ); ?>

	 <?php echo Form::submit('Update'); ?>

	 <?php echo Form::close(); ?>

	 
	 </td>
	 
	 </tr>
	   <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  
   

  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.operatorSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>