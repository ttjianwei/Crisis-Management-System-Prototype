<?php $__env->startSection('content'); ?>

<script>

  function ConfirmEscalate()
  {
  var x = confirm("Confirm escalate to Crisis?");
  if (x)
    return true;
  else
    return false;
  }
  
  function ConfirmDelete()
  {
  var x = confirm("Confirm delete Incident?");
  if (x)
    return true;
  else
    return false;
  }
</script>
	<p><b><center>Privilege level : System Admin</center></b></p>

	<center><?php echo $errors->first('message'); ?></center>
<table>
  <thead>
    <tr>
	  <th>Incident case ID</th>
      <th>Incident Name</th>
      <th>Incident Category</th>
      <th>Incident Description</th>
	  <th>Incident Location</th>
	  <th>Alert Level</th>
	  <th>Remarks</th>
	  <th>Lodge by</th>
	  <th>Time of Incident</th>
	  <th>Escalate</th>
	  <th>Delete</th>
    </tr>
  </thead>
  <tbody>
    
	  <?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	 <tr>
	 <td><?php echo $incident->caseID; ?></td>
	 <td><?php echo $incident->incidentName; ?></td>
	 <td><?php echo $incident->incidentCategory; ?></td>
	 <td><?php echo $incident->description; ?></td>
	 <td><?php echo $incident->incidentLocation; ?></td>
	 <td><?php echo $incident->alertLevel; ?></td>
	 <td><?php echo $incident->remarks; ?></td>
	 <td><?php echo $incident->loggedBy; ?></td>
	 <td><?php echo $incident->datetimeOfIncident; ?></td>
	 <td>
	 	 <?php echo Form::open(array('url'=>'escalateCrisis','method'=>'post','onsubmit' => 'return ConfirmEscalate()')); ?>

		 <?php echo Form::hidden('caseID', $incident->caseID ); ?>

		 <?php echo Form::hidden('incidentName', $incident->incidentName ); ?>

		 <?php echo Form::hidden('incidentCategory', $incident->incidentCategory); ?>

	     <?php echo Form::hidden('incidentDescription', $incident->description); ?>

		 <?php echo Form::hidden('incidentLocation', $incident->incidentLocation ); ?>

		 <?php echo Form::hidden('incidentAlertLevel', $incident->alertLevel); ?>

		 <?php echo Form::hidden('incidentRemarks', $incident->remarks ); ?>

		 <?php echo Form::hidden('incidentLoggedBy', $incident->loggedBy); ?>

		 <?php echo Form::hidden('incidentDateTime', $incident->datetimeOfIncident ); ?>	
		 <?php echo Form::submit('Escalate'); ?>

		 <?php echo Form::close(); ?>

	 </td>
	  <td> 
	 <?php echo Form::open(array('url'=>'deleteIncident','method'=>'post','onsubmit' => 'return ConfirmDelete()')); ?>

	 		 <?php echo Form::submit('Delete'); ?>

			 <?php echo Form::hidden('caseID', $incident->caseID ); ?>

	 <?php echo Form::close(); ?>

	 </td>
	 </tr>
	 
	   <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  
   

  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>