<?php $__env->startSection('content'); ?>

<script>

  function ConfirmDelete()
  {
  var x = confirm("Confirm Delete User?");
  if (x)
    return true;
  else
    return false;
  }

</script>

	<p><b><center>Privilege level : System Admin</center></b></p>

<body>
<div style="margin-left:100px">
<label for="id">

            <strong>
			Enter user ID to be deleted : </strong>
          </label>
		  
		  
 <?php echo Form::open(array('url'=>'removeUser','method'=>'post','onsubmit' => 'return ConfirmDelete()')); ?>

 
 <p>
<?php echo $errors->first('message'); ?>

</p>
   <?php echo Form::text('id',null,array('class'=>'input' , 'id'=>'id')); ?>

	 		 <?php echo Form::submit('Delete'); ?>

	 <?php echo Form::close(); ?>

	 </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>