<?php
$username="root";
$password="93829359";
$database="crux";
?>