
@extends('layouts.publicSidebar')
@section('content')
	<p><b><center>Privilege level : Public Liaison</center></b></p>
	
	
@stop