@extends('layouts.sidebar')
@section('content')

<p><b><center>Privilege level : System Admin</center></b></p>
<center>
<iframe src="https://www.chatcrypt.com/iframe.php" width="468" height="60" frameborder="0"></iframe>
</center>
@stop