<html>
<head>
<body style="backgroun:black; color:white ">
<h1>This is a testing mail from crux</h1>
<p>crux test mail</p>
</body>
</head>
</html>