
<div class="header">
<div class="container">
<h1 class="header-heading">C.R.U.X Web Application</h1>
</div>
</div>


<div class="nav-bar">
<div class="container">

<ul class="nav"> 
	<li><a href="home">Home</a></li>
	<li><a href="viewIncident">View Incident</a></li>
	<li><a href="viewCrisis">View Crisis</a></li>
	<li><a href="viewAssets">View Assets</a></li>
	<li><a href="deleteAccount">Delete Users</a></li>
	<li><a href="commanderReport">Display Report</a></li>
	<li><a href="clear-cache" >Logout</a></li>
</ul>
</div>
</div>