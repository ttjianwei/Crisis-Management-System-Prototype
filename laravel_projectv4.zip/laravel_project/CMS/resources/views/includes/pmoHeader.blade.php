<div class="header">
<div class="container">
<h1 class="header-heading">C.R.U.X Web Application</h1>
</div>
</div>


<div class="nav-bar">
<div class="container">

<ul class="nav"> 
	<li><a href="pmoView">Home</a></li>
	<li><a href="pmoCrisis">View Crisis</a></li>
	<li><a href="pmoEmail">View Emails</a></li>
	<li><a href="clear-cache" >Logout</a></li>
</ul>
</div>
</div>