<?php

namespace CRUX;

use Illuminate\Database\Eloquent\Model;

class EmailManager extends Model
{
    //
}
